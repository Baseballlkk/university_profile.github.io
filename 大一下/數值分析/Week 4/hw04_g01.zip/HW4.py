import numpy as np
import For
import Gauss

n = int(input('Please input the size of the square matrix :'))

# set A square matrix
A = np.empty((n,n))
for i in range(n):
    for j in range(n):
        print('A[',i,',',j,'] =')
        A[i,j] = input()

# set AX (n x 1) matrix
AX = np.empty((n,1))
for i in range(n):
    print('AX[',i,', 0 ] =')
    AX[i,0] = input()

print(np.linalg.solve(A,AX))

# set X (n x 1) matrix
X = np.empty((n,1))
A,AX = For.ForwardSub(n, A, AX)
X = Gauss.Gauss_elim(n,A,AX,X)
print(A)
print(AX)
print(X)
